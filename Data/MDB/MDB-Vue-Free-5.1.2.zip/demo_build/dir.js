module.exports = {
  main: 'demo'
}